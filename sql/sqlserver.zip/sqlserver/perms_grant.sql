
GRANT SELECT, Alter ON dbo.View_99 TO BB, t1_igor
DeNY SELECT, Alter ON dbo.View_99 TO BB, t1_igor;