use mytest;
SELECT * from [sys].[types]