use msdb
GO

CREATE QUEUE dbo.GrantEventNotificationQueue 
GO 

CREATE SERVICE [//msdb/GrantEventNotificationService] 
ON QUEUE dbo.GrantEventNotificationQueue 
([http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]) 
GO


create event notification NotifyPermissionEventsDDL_SERVER_SECURITY_EVENTS
on server for DDL_SERVER_SECURITY_EVENTS  to service '//msdb/GrantEventNotificationService', 'current database'
GO

create event notification NotifyPermissionEventsDDL_DATABASE_SECURITY_EVENTS
on server for DDL_DATABASE_SECURITY_EVENTS  to service '//msdb/GrantEventNotificationService', 'current database'
GO


SELECT * FROM sys.server_event_notifications 
GO