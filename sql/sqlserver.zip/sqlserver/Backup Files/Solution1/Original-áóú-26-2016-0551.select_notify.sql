use mytest;

select * from sys.service_queues
GO
select * from sys.services
GO
SELECT * FROM sys.events
GO
SELECT * FROM sys.event_notifications
GO
SELECT * FROM sys.server_event_notifications 
GO