use mytest;
--CREATE ASYMMETRIC KEY PacificSales09   
--    WITH ALGORITHM = RSA_2048   
--    ENCRYPTION BY PASSWORD = '<enterStrongPasswordHere>';   
--GO  
GRANT CONTROL
    ON ASYMMETRIC KEY :: PacificSales09   
       TO t1_igor;