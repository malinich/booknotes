use mytest
SELECT type_desc FROM [sys].[objects]
group by type_desc
order by type_desc