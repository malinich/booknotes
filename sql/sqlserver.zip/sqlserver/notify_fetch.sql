use msdb;
DECLARE @TargetDialogHandle UNIQUEIDENTIFIER;
DECLARE @EventMessage XML; 
DECLARE @EventMessageTypeName sysname; 
WAITFOR 
( RECEIVE TOP(10) 
@TargetDialogHandle = conversation_handle, 
@EventMessage = CONVERT(XML, message_body), 
@EventMessageTypeName = message_type_name 
FROM GrantEventNotificationQueue 
), TIMEOUT 500; 
SELECT @TargetDialogHandle AS DialogHandle, @EventMessageTypeName AS MessageTypeName, 
@EventMessage.value('(/EVENT_INSTANCE/EventType)[1]', 'varchar(128)' ) as EventType, 
@EventMessage.value('(/EVENT_INSTANCE/ServerName)[1]', 'varchar(128)' ) as ServerName, 
@EventMessage.value('(/EVENT_INSTANCE/DatabaseName)[1]', 'varchar(128)' ) as DatabaseName, 
@EventMessage.value('(/EVENT_INSTANCE/LoginName)[1]', 'varchar(128)' ) as LoginName, 
@EventMessage.value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)') AS TSQLCommand, 
@EventMessage.value('(/EVENT_INSTANCE/TextData)[1]', 'varchar(128)' ) AS TextData, 
@EventMessage.value('(/EVENT_INSTANCE/Severity)[1]', 'varchar(128)' ) AS Severity, 
@EventMessage.value('(/EVENT_INSTANCE/Error)[1]', 'varchar(128)' ) AS ErrorNumber