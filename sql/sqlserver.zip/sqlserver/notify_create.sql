use msdb
GO

CREATE QUEUE GrantEventNotificationQueue 
GO 

CREATE SERVICE [GrantEventNotificationService] 
ON QUEUE GrantEventNotificationQueue 
([http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]) 
GO


create event notification PermissionEvents_SERVER_SECURITY_EVENTS
on server for DDL_SERVER_SECURITY_EVENTS  to service 'GrantEventNotificationService', 'current database'
GO

create event notification PermissionEvents_DATABASE_SECURITY_EVENTS
on server for DDL_DATABASE_SECURITY_EVENTS  to service 'GrantEventNotificationService', 'current database'
GO

create event notification PermissionEvents_ALTER_DATABASE
on server for ALTER_DATABASE  to service 'GrantEventNotificationService', 'current database'
GO

create event notification Permission_RENAME
on server for RENAME  to service 'GrantEventNotificationService', 'current database'
GO

--create event notification Permission_DROP_DATABASE
--on server for DROP_DATABASE  to service 'GrantEventNotificationService', 'current database'
--GO

--create event notification Permission_DDL_EVENTS
--on server for DDL_EVENTS  to service 'GrantEventNotificationService', 'current database'
--GO

--create event notification Permission_DDL_DATABASE_LEVEL_EVENTS
--on server for DDL_DATABASE_LEVEL_EVENTS  to service 'GrantEventNotificationService', 'current database'
--GO

create event notification Permission_OBJECT_DELETED
on server for OBJECT_DELETED  to service 'GrantEventNotificationService', 'current database'
GO

SELECT * FROM sys.server_event_notifications 
GO