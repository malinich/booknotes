use msdb;

select * from sys.service_queues
union
select * from sys.services
union
SELECT * FROM sys.events
union
SELECT * FROM sys.event_notifications
union
SELECT * FROM sys.server_event_notifications 
