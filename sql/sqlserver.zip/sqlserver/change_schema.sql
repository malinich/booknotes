use [mytest]
go

ALTER SCHEMA dbo TRANSFER guest.my_test_90;