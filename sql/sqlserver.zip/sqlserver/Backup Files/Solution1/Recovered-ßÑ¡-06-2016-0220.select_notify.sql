use msdb;

select * from sys.service_queues
go
select * from sys.services
go
SELECT * FROM sys.events
go
SELECT * FROM sys.event_notifications
go
SELECT * FROM sys.server_event_notifications 
