SELECT *
FROM sys.sysusers us  
LEFT JOIN sys.syslogins ON us.sid = sys.syslogins.sid
JOIN  sys.database_role_members rm ON us.uid = rm.member_principal_id
JOIN sys.database_principals dp ON rm.role_principal_id =  dp.principal_id