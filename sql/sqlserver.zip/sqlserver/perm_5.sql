use mytest;

SELECT 
[ID],
  [UserName],
  STUFF((
    SELECT ', ' + [ObjectType] +' : ' +  COALESCE([ObjectName], '') + ':' + CAST([PermissionType] AS VARCHAR(MAX)) 
    FROM (
	
			SELECT  
				ulogin.principal_id as [ID],
				[UserName] = ulogin.[name],
				[PermissionType] = perm.[permission_name],       
				[PermissionState] = perm.[state_desc],       
				[ObjectType] = CASE perm.[class] 
									WHEN 1 THEN obj.type_desc               -- Schema-contained objects
									ELSE perm.[class_desc]                  -- Higher-level objects
							   END,       
				[ObjectName] = CASE perm.[class] 
									WHEN 0 THEN DB_NAME()
									WHEN 1 THEN OBJECT_NAME(perm.major_id)  -- General objects
									WHEN 3 THEN schem.[name]                -- Schemas
									WHEN 4 THEN imp.[name]                  -- Impersonations
							   END

			FROM    
				--database user
				sys.database_principals princ  
			LEFT JOIN
				--Login accounts
				sys.server_principals ulogin on princ.[sid] = ulogin.[sid]
			LEFT JOIN        
				--Permissions
				sys.database_permissions perm ON perm.[grantee_principal_id] = princ.[principal_id]
			LEFT JOIN
				--Table columns
				sys.columns col ON col.[object_id] = perm.major_id 
								AND col.[column_id] = perm.[minor_id]
			LEFT JOIN
				sys.objects obj ON perm.[major_id] = obj.[object_id]
			LEFT JOIN
				sys.schemas schem ON schem.[schema_id] = perm.[major_id]
			LEFT JOIN
				sys.database_principals imp ON imp.[principal_id] = perm.[major_id]
			WHERE 
				princ.[type] IN ('S','U','G') AND
				-- No need for these system accounts
				princ.[name] NOT IN ('sys', 'INFORMATION_SCHEMA')
	) AS NameValues
    WHERE (NameValues.[ID] = Results.[ID]) 
    FOR XML PATH(''),TYPE).value('(./text())[1]','VARCHAR(MAX)')
  ,1,2,'') AS NameValues
FROM (

	SELECT 
		ulogin.principal_id as [ID],
		ulogin.[name] as [UserName],
		princ.[type] 
	FROM    
		sys.database_principals princ  
	LEFT JOIN
		sys.server_principals ulogin on princ.[sid] = ulogin.[sid]
	WHERE 
		princ.[type] IN ('S','U','G') AND
		princ.[name] NOT IN ('sys', 'INFORMATION_SCHEMA')
	 ) as Results

where [ID] is NOT NULL
GROUP BY [ID], [UserName]

