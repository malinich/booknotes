use mytest
GO



DROP EVENT NOTIFICATION NotifyPermissionEventsDDL_SERVER_SECURITY_EVENTS ON Server 
GO
DROP EVENT NOTIFICATION NotifyPermissionEventsDDL_DATABASE_SECURITY_EVENTS ON Server 
GO

DROP SERVICE [//mytest/EventNotificationService] 
GO
DROP QUEUE EventNotificationQueue
GO