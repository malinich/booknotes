use mytest;

--CREATE SYMMETRIC KEY MarketingXXVI   
--WITH ALGORITHM = AES_128,  
--KEY_SOURCE   
--     = 'The square of the hypotenuse is equal to the sum of the squares of the sides',  
--IDENTITY_VALUE = 'Pythagoras'  
--ENCRYPTION BY CERTIFICATE Shipping04;  
--GO  

--GRANT REFERENCES   
--    ON SYMMETRIC KEY :: MarketingXXVI    
--    TO t1_igor
