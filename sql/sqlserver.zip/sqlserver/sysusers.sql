
use [slas\las]
Select * from sys.sysusers;