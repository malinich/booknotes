use mytest
--go
--grant alter on ASSEMBLY::"Microsoft.SqlServer.Types" to [BB];
go
--grant  alter on OBJECT::dbo.View_99 to [BB] ;
--grant alter on ASSEMBLY::"Microsoft.SqlServer.Types" to [BB];
--ALTER SCHEMA dbo TRANSFER guest.my_test_90;
--grant  alter on DATABASE::mytest to [BB] ;
ALTER DATABASE [Northwind_] Modify database_id = [19];  
GO  