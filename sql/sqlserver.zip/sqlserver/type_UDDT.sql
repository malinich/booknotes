use mytest;
--CREATE TYPE SSN  
--FROM varchar(11) NOT NULL ;  

--CREATE TYPE Utf8String   
--EXTERNAL NAME "Microsoft.ReportingServices.Interfaces"
CREATE TYPE LocationTableType AS TABLE 
( LocationName VARCHAR(50)
, CostRate INT );
GO
--GRANT EXECUTE ON TYPE :: dbo.test
--    TO t1_igor