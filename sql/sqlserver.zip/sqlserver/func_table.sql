-- ================================================
-- Template generated from Template Explorer using:
-- Create Inline Function (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the function.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION func_table
(	
	-- Add the parameters for the function here
	@LastName varchar (30)
)
RETURNS @mytable_info TABLE
(
	FirstName nvarchar(50) NULL, 
    LastName nvarchar(50) NULL
)
AS
BEGIN 
DECLARE 
	@FirstName nvarchar(50)
	SELECT 
        @FirstName = col_1, 
        @LastName = col_2
    FROM my_table_1
	RETURN
END;
GO
