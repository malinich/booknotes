--create event notification Permission_RENAME
--on server for RENAME to service 'GrantEventNotificationService', 'current database'

use mytest
--ALTER SCHEMA guest TRANSFER guest.[View_98];  
--SELECT DB_ID('msdb')
SELECT * FROM master.dbo.sysdatabases