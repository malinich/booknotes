USE  [master];
WITH RoleMembers (member_principal_id, role_principal_id)
AS (
  SELECT
    rm.member_principal_id,
    rm.role_principal_id
  FROM sys.database_role_members rm
  UNION ALL
  SELECT
    RoleMembers.member_principal_id,
    rm1.role_principal_id
  FROM sys.database_role_members rm1
    INNER JOIN RoleMembers
      ON rm1.member_principal_id = RoleMembers.role_principal_id
)
            SELECT DISTINCT
              COALESCE(rp.name, roleus.name)           AS principal_name,
			  mp.sid,
			  roleus.sid,
              COALESCE(mp.sid, (CASE 
									WHEN (
									(us.isntgroup=0 or roleus.isntgroup = 0 or
									us.issqlrole=0 or roleus.issqlrole = 0) and (
									us.isntuser=1 or roleus.isntuser=1 or
									us.issqluser=1 or roleus.issqluser=1)) then roleus.sid
								  ELSE NULL END))	as user_sid,
              COALESCE(rp.sid, (CASE
									WHEN (
									us.isntuser=1 or roleus.isntuser=1 or
									us.issqluser=1 or roleus.issqluser=1) then Null
								ELSE roleus.sid END	))	as role_sid,
              COALESCE(us.uid, roleus.uid)              as uid,
              COALESCE(us.name, roleus.name)            as name,
              COALESCE(us.isntname,roleus.isntname)     as isntname,
              COALESCE(us.isntgroup, roleus.isntgroup)  as isntgroup,
              COALESCE(us.isntuser, roleus.isntuser)    as isntuser,
              COALESCE(us.issqluser, roleus.issqluser)  as issqluser,
              COALESCE(us.issqlrole, roleus.issqlrole)  as issqlrole,
			  roleus.sid,
              USER_ID (us.name),
              DB_NAME() AS db_name
            FROM RoleMembers
              RIGHT JOIN sys.database_principals rp   ON (RoleMembers.role_principal_id = rp.principal_id)
              RIGHT JOIN sys.database_principals mp   ON (RoleMembers.member_principal_id = mp.principal_id)
              RIGHT JOIN sys.sysusers us              ON (us.uid = RoleMembers.member_principal_id)
              RIGHT JOIN sys.sysusers roleus          ON (roleus.uid = RoleMembers.member_principal_id)
              Left JOIN sys.syslogins           ON (roleus.sid = sys.syslogins.sid)

			  WHERE roleus.sid IS NOT NULL or us.sid is NOT NULL

       