use [DD]
GO

--CREATE CERTIFICATE Shipping04   
--   ENCRYPTION BY PASSWORD = '111D4bb925DGvbd2439587y'  
--   WITH SUBJECT = 'Sammamish Shipping Records',   
--   EXPIRY_DATE = '20161231';  
--GO
--GRANT TAKE OWNERSHIP
--    ON CERTIFICATE :: Shipping04   
--    TO guest;

--CREATE ASYMMETRIC KEY PacificSales10   
--    WITH ALGORITHM = RSA_2048   
--    ENCRYPTION BY PASSWORD = '<enterStrongPasswordHere>';   
--GO  
--Grant alter on ASYMMETRIC KEY::PacificSales09 to G1;
Grant control on DATABASE::DD to G1;
--CREATE SYMMETRIC KEY MarketingXXVI   
--WITH ALGORITHM = AES_128,  
--KEY_SOURCE   
--     = 'The square of the hypotenuse is equal to the sum of the squares of the sides',  
--IDENTITY_VALUE = 'Pythagoras'  
--ENCRYPTION BY CERTIFICATE Shipping05;  
--GO
--CREATE ASSEMBLY HelloWorld   
--FROM "C:\Program Files\Microsoft SQL Server\100\Setup Bootstrap\Release\x64\Microsoft.SQL.Chainer.Product.dll"
--WITH PERMISSION_SET = SAFE;

--CREATE QUEUE ExpenseQueue ;  
--GRANT ALTER ON  ExpenseQueue TO guest;

-- ******
-- user type, user table
--CREATE TYPE SSN  FROM varchar(11) NOT NULL ;  
--CREATE TYPE LocationTableType AS TABLE ( LocationName VARCHAR(50) , CostRate INT ); 

--******
-- procedure
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO

--CREATE PROCEDURE uspGetEmployeesTest2    
--	@LastName varchar(MAX),   
--    @FirstName nvarchar(50)   
--AS
--BEGIN
--	SET NOCOUNT ON;
--	SELECT @LastName, @FirstName
--FROM TT  
--WHERE TT.TT = @FirstName AND TT.QQ like @LastName;  
--END
--GO
-- end procedure

--***********
-- SCALAR FUNCTION
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO

--CREATE FUNCTION scalar_test
--(
--	@sc_1 varchar(30)
--)
--RETURNS varchar
--AS
--BEGIN
--	DECLARE @sc_0 varchar;
--	set @sc_0 = @sc_1 + 'sd';
--	RETURN @sc_0
--END
--GO

--***********
-- TABLE FALUED FUNC
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO

--CREATE FUNCTION func_table
--(	
--	@LastName varchar (30)
--)
--RETURNS @mytable_info TABLE
--(
--	FirstName nvarchar(50) NULL, 
--    LastName nvarchar(50) NULL
--)
--AS
--BEGIN 
--DECLARE 
--	@FirstName nvarchar(50)
--	SELECT 
--        @FirstName = col_1, 
--        @LastName = col_2
--    FROM my_table_1
--	RETURN
--END;
--GO

--******
-- object
--grant  delete, insert on OBJECT::dbo.r2 to guest ;
--CREATE TABLE t1(
--name int
--);
--Grant alter on OBJECT::t1 to G1;
--drop table dbo.t1;