use msdb
go
SELECT CAST(message_body AS XML) AS message_in_xml 
FROM GrantEventNotificationQueue

GO