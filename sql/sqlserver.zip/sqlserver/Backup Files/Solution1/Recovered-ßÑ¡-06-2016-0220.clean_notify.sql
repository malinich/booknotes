use msdb
GO

DROP EVENT NOTIFICATION PermissionEvents_DATABASE_SECURITY_EVENTS ON Server 
GO
DROP EVENT NOTIFICATION PermissionEvents_SERVER_SECURITY_EVENTS ON Server 
GO
DROP SERVICE [GrantEventNotificationService]
GO
DROP QUEUE GrantEventNotificationQueue
GO