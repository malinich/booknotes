use mytest;

--CREATE QUEUE ExpenseQueue ;  

GRANT ALTER ON  
        ExpenseQueue
TO t1_igor
