use mytest

CREATE QUEUE dbo.EventNotificationQueue 
GO 

CREATE SERVICE [//mytest/EventNotificationService] 
ON QUEUE dbo.EventNotificationQueue 
([http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]) 
GO

CREATE EVENT NOTIFICATION NotifyALTERTABLEEvents 
ON DATABASE 
FOR ALTER_TABLE 
TO SERVICE '//mytest/EventNotificationService' , 'current database' 
GO 

create event notification NotifyPermissionEvents
on server for ALTER_CREDENTIAL  to service '//mytest/EventNotificationService', 'current database'
GO

create event notification NotifyPermissionEvents_ADOAE
on server for AUDIT_DATABASE_OBJECT_ACCESS_EVENT  to service '//mytest/EventNotificationService', 'current database'
GO

SELECT * FROM sys.server_event_notifications 
GO