use mytest;
select * from sys.database_permissions
Go