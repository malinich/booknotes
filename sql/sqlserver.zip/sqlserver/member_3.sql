USE  master;
WITH RoleMembers (member_principal_id, role_principal_id)
AS (
  SELECT
    rm.member_principal_id,
    rm.role_principal_id
  FROM sys.database_role_members rm
  UNION ALL
  SELECT
    RoleMembers.member_principal_id,
    rm1.role_principal_id
  FROM sys.database_role_members rm1
    INNER JOIN RoleMembers
      ON rm1.member_principal_id = RoleMembers.role_principal_id
)
SELECT
  rp.name   AS principal_name,
    rp.sid,
  us.sid,
  us.name,
  us.isntname,
  us.isntgroup,
  us.isntuser,
  issqluser,
  issqlrole,
  sys.syslogins.loginname,
  DB_NAME() AS db_name
FROM RoleMembers
  JOIN sys.database_principals rp ON (RoleMembers.role_principal_id = rp.principal_id)
  JOIN sys.database_principals mp ON (RoleMembers.member_principal_id = mp.principal_id)
  JOIN sys.sysusers us ON (us.uid = RoleMembers.member_principal_id)
  left JOIN sys.syslogins ON us.sid = sys.syslogins.sid
ORDER BY rp.principal_id
        