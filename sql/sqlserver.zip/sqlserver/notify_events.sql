select * from sys.event_notification_event_types
order by 'type_name'
