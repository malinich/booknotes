
WITH RoleMembers (member_principal_id, role_principal_id)
            AS (
              SELECT
                rm.member_principal_id,
                rm.role_principal_id
              FROM sys.server_role_members rm
              UNION ALL
              SELECT
                RoleMembers.member_principal_id,
                rm1.role_principal_id
              FROM sys.server_role_members rm1
              INNER JOIN RoleMembers
              ON rm1.member_principal_id = RoleMembers.role_principal_id
            )
            SELECT DISTINCT
              COALESCE(rp.name, mp.name)              AS principal_name,
              mp.sid  AS sid,
              rp.sid  AS role_sid,
			  
              CASE WHEN(mp.type in ('U', 'G')) THEN 1 ELSE 0 END		AS isntname,
              CASE WHEN(mp.type in ('G')) THEN 1 ELSE 0 END				AS isntgroup,
              CASE WHEN(mp.type in ('U')) THEN 1 ELSE 0 END				AS isntuser,
              CASE WHEN(mp.type in ('S', 'C', 'K')) THEN 1 ELSE 0 END	AS issqluser,
              CASE WHEN(mp.type in ('R')) THEN 1 ELSE 0 END				AS issqlrole,
			
			  CAST(CAST(COALESCE(mp.name , rp.name) AS VARBINARY(MAX)) AS NVARCHAR(MAX)) AS loginname,
			  @@SERVERNAME  as obj_id ,
			  *
            FROM RoleMembers
			
			
              RIGHT JOIN sys.server_principals rp   ON (RoleMembers.role_principal_id = rp.principal_id)
			  RIGHT JOIN sys.server_principals mp   ON (RoleMembers.member_principal_id = mp.principal_id)
			  
			  
			  
              
